//
//  QRefreshView2.h
//  AniDemo1
//
//  Created by daixu on 15/6/3.
//  Copyright (c) 2015年 daixu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRefreshView2 : UIView

- (void)beginAni;

@end
