//
//  QRefreshView.h
//  ReactiveCocoaStudy
//
//  Created by daixunry on 15/5/20.
//  Copyright (c) 2015年 daixu. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface QRefreshView : UIView

- (void)beginAni;

@end
