# 三个动画效果的实现

第一个是QRefresh,实现了https://dribbble.com/shots/2064446-Refresh 的设计.

<img src="https://github.com/daixunry/AnimationSharePartOne/blob/master/refresh.gif" width = "400px" height = "300px" alt="图片名称" align=center />


第二个模仿了网易新闻个人空间的水波效果

<img src="https://github.com/daixunry/AnimationSharePartOne/blob/master/waveGif.gif" width = "400px" height = "122px" alt="图片名称" align=center />


第三个是一个一度比较火的3D sideBar效果， 来自与http://www.raywenderlich.com/87268/3d-effect-taasky-swift ,但是完全不同的实现思路。

<img src="https://github.com/daixunry/AnimationSharePartOne/blob/master/sideBar3d.gif" width = "400px" height = "710px" alt="图片名称" align=center />



